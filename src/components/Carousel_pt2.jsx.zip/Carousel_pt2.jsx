import React, { useState, useEffect } from "react";
import "../styles/Carousel.css";

const Carousel = ({ mapping = [], onSelect }) => {
  const total = 20;
  const [selectedBox, setSelectedBox] = useState(null);
  const [revealedNumber, setRevealedNumber] = useState(null);
  const [disappeared, setDisappeared] = useState([]);
  const [sequenceStarted, setSequenceStarted] = useState(false);
  const [regionQueue, setRegionQueue] = useState([]);
  const [currentRegion, setCurrentRegion] = useState(null);
  const [rotationPaused, setRotationPaused] = useState(false);

  const playerRegion = mapping.find((m) => m.isPlayer)?.name;
  const regionMap = Object.fromEntries(mapping.map((m) => [m.name, m.number]));

  useEffect(() => {
    if (sequenceStarted && regionQueue.length === 0) {
      setTimeout(() => {
        onSelect();
      }, 1200);
    }

    if (sequenceStarted && regionQueue.length > 0) {
      const [next, ...rest] = regionQueue;
      const availableBoxes = [...Array(total).keys()].filter((i) => !disappeared.includes(i));
      const nextBox = availableBoxes[0];
      if (nextBox == null) return;

      setTimeout(() => {
        setSelectedBox(nextBox);
        setCurrentRegion(next);
        setTimeout(() => {
          setRevealedNumber(regionMap[next]);
          setTimeout(() => {
            setDisappeared((prev) => [...prev, nextBox]);
            setSelectedBox(null);
            setRevealedNumber(null);
            setCurrentRegion(null);
            setRegionQueue(rest);
          }, 1000);
        }, 800);
      }, 500);
    }
  }, [sequenceStarted, regionQueue, disappeared, regionMap, onSelect]);

  const handleClick = (i) => {
    if (selectedBox !== null || sequenceStarted) return;

    setRotationPaused(true);
    setSelectedBox(i);
    setCurrentRegion(playerRegion);

    setTimeout(() => {
      setRevealedNumber(regionMap[playerRegion]);
      setTimeout(() => {
        setDisappeared((prev) => [...prev, i]);
        setSelectedBox(null);
        setRevealedNumber(null);
        setCurrentRegion(null);

        const restRegions = mapping
          .filter((r) => !r.isPlayer)
          .map((r) => r.name);
        setRegionQueue(restRegions);
        setSequenceStarted(true);
      }, 1000);
    }, 800);
  };

  return (
    <div className="carousel-container">
      {/* ✅ Nome regione FISSO al centro */}
      <div className="region-display">
        {currentRegion || playerRegion}
      </div>

      {/* 🎡 Rotazione dei pacchi */}
      <div className={`carousel-rotating-disc ${rotationPaused ? "paused" : ""}`}>
        {Array.from({ length: total }).map((_, i) => {
          const angle = (360 / total) * i;
          const isSelected = i === selectedBox;
          const isGone = disappeared.includes(i);

          return (
            <div
              key={i}
              className={
                "carousel-box" +
                (isSelected ? " selected" : "") +
                (isGone ? " gone" : "")
              }
              onClick={() => handleClick(i)}
              style={{
                transform: `rotate(${angle}deg) translateY(-280px)`
              }}
            >
              {isSelected && revealedNumber ? revealedNumber : ""}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Carousel;
